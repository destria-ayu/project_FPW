<nav class="bg-white border-b border-gray-200">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
            <div class="flex space-x-6">
                <!-- Menu Dashboard (Bisa diakses Admin & Kasir) -->
                <a href="{{ route('dashboard') }}"
                    class="font-semibold {{ request()->routeIs('dashboard') ? 'text-indigo-600' : 'text-gray-700' }}">
                    Dashboard
                </a>

                <!-- Menu Khusus Admin -->
                @if (auth()->user()->role === 'admin')
                    <a href="{{ route('categories.index') }}"
                        class="{{ request()->routeIs('categories.*') ? 'text-indigo-600' : 'text-gray-500' }}">
                        Kategori
                    </a>

                    <a href="{{ route('products.index') }}"
                        class="{{ request()->routeIs('products.*') ? 'text-indigo-600' : 'text-gray-500' }}">
                        Produk
                    </a>
                @endif

                <a href="{{ route('suppliers.index') }}"
                    class="{{ request()->routeIs('suppliers.*') ? 'text-indigo-600' : 'text-gray-500' }}">
                    Supplier
                </a>

                <a href="{{ route('purchases.index') }}"
                    class="{{ request()->routeIs('purchases.*') ? 'text-indigo-600' : 'text-gray-500' }}">
                    Purchase
                </a>

                @if (auth()->user()->role === 'admin')
                    <a href="{{ route('report.sales') }}"
                        class="{{ request()->routeIs('report.sales') ? 'text-indigo-600' : 'text-gray-500' }}">
                        Laporan
                    </a>
                @endif

                <!-- Menu Transaksi (Kasir & Admin) -->
                <a href="{{ route('pos.index') }}"
                    class="{{ request()->routeIs('pos.index') ? 'text-indigo-600' : 'text-gray-500' }}">
                    Transaksi
                </a>

                <!-- Menu Khusus Kasir (Riwayat Transaksi Saya) -->
                @if (auth()->user()->role === 'kasir')
                    <a href="{{ Route::has('pos.history') ? route('pos.history') : '#' }}"
                        class="{{ request()->routeIs('pos.history') ? 'text-indigo-600' : 'text-gray-500' }}">
                        Riwayat Transaksi Saya
                    </a>
                @endif
            </div>

            <div class="flex items-center space-x-4 text-sm">
                <span class="text-gray-600">{{ auth()->user()->name }} ({{ strtoupper(auth()->user()->role) }})</span>
                <form action="{{ route('logout') }}" method="POST">
                    @csrf
                    <button type="submit" class="text-gray-500 hover:text-red-600">Keluar</button>
                </form>
            </div>
        </div>
    </div>
</nav>