<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detail Pembelian</title>

    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100">

    <div class="max-w-6xl mx-auto p-6">

        
        <div class="flex justify-between items-center mb-6">

            <h1 class="text-3xl font-bold">
                Detail Pembelian
            </h1>

            <a href="<?php echo e(route('purchases.index')); ?>"
               class="text-gray-600 hover:text-indigo-600">
                Kembali
            </a>

        </div>


        
        <div class="bg-white rounded-lg shadow p-6 mb-6">

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

                <div>
                    <p class="text-sm text-gray-500">
                        Supplier
                    </p>

                    <p class="text-lg font-semibold">
                        <?php echo e($purchase->supplier->name); ?>

                    </p>
                </div>


                <div>
                    <p class="text-sm text-gray-500">
                        Tanggal Pembelian
                    </p>

                    <p class="text-lg font-semibold">
                        <?php echo e($purchase->date); ?>

                    </p>
                </div>


                <div>
                    <p class="text-sm text-gray-500">
                        Total Pembelian
                    </p>

                    <p class="text-lg font-semibold">
                        Rp <?php echo e(number_format($purchase->total_amount, 0, ',', '.')); ?>

                    </p>
                </div>

            </div>

        </div>


        
        <div class="bg-white rounded-lg shadow overflow-hidden">

            <div class="p-6">
                <h2 class="text-xl font-bold">
                    Produk yang Dibeli
                </h2>
            </div>


            <table class="w-full border-collapse">

                <thead>

                    <tr class="bg-gray-100">

                        <th class="border p-3 text-left">
                            No
                        </th>

                        <th class="border p-3 text-left">
                            Produk
                        </th>

                        <th class="border p-3 text-left">
                            Harga Beli
                        </th>

                        <th class="border p-3 text-left">
                            Jumlah
                        </th>

                        <th class="border p-3 text-left">
                            Subtotal
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $purchase->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            <td class="border p-3">
                                <?php echo e($loop->iteration); ?>

                            </td>

                            <td class="border p-3">
                                <?php echo e($detail->product->name); ?>

                            </td>

                            <td class="border p-3">
                                Rp <?php echo e(number_format($detail->buy_price, 0, ',', '.')); ?>

                            </td>

                            <td class="border p-3">
                                <?php echo e($detail->quantity); ?>

                            </td>

                            <td class="border p-3">
                                Rp <?php echo e(number_format($detail->buy_price * $detail->quantity, 0, ',', '.')); ?>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="5"
                                class="border p-6 text-center text-gray-500">

                                Tidak ada detail produk.

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>


                <tfoot>

                    <tr class="bg-gray-50">

                        <td colspan="4"
                            class="border p-3 text-right font-bold">

                            Total Pembelian

                        </td>

                        <td class="border p-3 font-bold">

                            Rp <?php echo e(number_format($purchase->total_amount, 0, ',', '.')); ?>


                        </td>

                    </tr>

                </tfoot>

            </table>

        </div>

    </div>

</body>

</html><?php /**PATH C:\xampp\fpw\resources\views/purchases/show.blade.php ENDPATH**/ ?>