<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Kategori - PosKita</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

    <?php echo $__env->make('layouts.navigator', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container mx-auto mt-8 px-4 max-w-4xl">
        <h1 class="text-2xl font-bold mb-4">Daftar Kategori</h1>

        <!-- Notifikasi Sukses -->
        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>
        
        <!-- Tombol Tambah -->
        <a href="<?php echo e(route('categories.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded mb-4 inline-block">
            + Tambah Kategori
        </a>

        <!-- Tabel Kategori -->
        <div class="bg-white shadow-md rounded my-6 overflow-x-auto">
            <table class="min-w-full table-auto">
                <thead>
                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                        <th class="py-3 px-6 text-left w-20">No</th>
                        <th class="py-3 px-6 text-left">Nama Kategori</th>
                    </tr>
                </thead>
                <tbody class="text-gray-600 text-sm font-light">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                        <td class="py-3 px-6 text-left"><?php echo e($loop->iteration); ?></td>
                        <td class="py-3 px-6 text-left text-base font-medium"><?php echo e($category->name); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="2" class="py-3 px-6 text-center text-gray-500 font-bold">Belum ada data kategori.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\coba\resources\views/categories/index.blade.php ENDPATH**/ ?>