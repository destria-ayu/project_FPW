<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Produk</title>

    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100">

    <div class="p-6">

        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">
                Data Produk
            </h1>

            <a href="<?php echo e(route('products.create')); ?>"
               class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md">
                + Tambah Produk
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="mb-4 p-3 bg-green-100 text-green-700 rounded-md">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="bg-white rounded-lg shadow overflow-hidden">

            <table class="w-full border-collapse">

                <thead>
                    <tr class="bg-gray-100">
                        <th class="border p-3 text-left">No</th>
                        <th class="border p-3 text-left">Kode Produk</th>
                        <th class="border p-3 text-left">Nama Produk</th>
                        <th class="border p-3 text-left">Satuan</th>
                        <th class="border p-3 text-left">Harga</th>
                        <th class="border p-3 text-left">Stok</th>
                        <th class="border p-3 text-left">Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr class="hover:bg-gray-50">

                            <td class="border p-3">
                                <?php echo e($products->firstItem() + $loop->index); ?>

                            </td>

                            <td class="border p-3">
                                <?php echo e($product->code); ?>

                            </td>

                            <td class="border p-3">
                                <?php echo e($product->name); ?>

                            </td>

                            <td class="border p-3">
                                <?php echo e($product->unit); ?>

                            </td>

                            <td class="border p-3">
                                Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

                            </td>

                            <td class="border p-3">
                                <?php echo e($product->stock); ?>

                            </td>

                            <td class="border p-3">

                                <a href="<?php echo e(route('products.edit', $product)); ?>"
                                   class="text-blue-600 hover:underline">
                                    Edit
                                </a>

                                <form action="<?php echo e(route('products.destroy', $product)); ?>"
                                      method="POST"
                                      class="inline">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit"
                                            class="text-red-600 hover:underline ml-2"
                                            onclick="return confirm('Yakin ingin menghapus produk ini?')">
                                        Hapus
                                    </button>

                                </form>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>
                            <td colspan="7"
                                class="border p-6 text-center text-gray-500">
                                Belum ada data produk.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <div class="mt-4">
            <?php echo e($products->links()); ?>

        </div>

    </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\coba\resources\views/product/index.blade.php ENDPATH**/ ?>