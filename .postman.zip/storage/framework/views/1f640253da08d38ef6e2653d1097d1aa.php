<div <?php echo e($attributes->merge(['class' => 'bg-white overflow-hidden shadow-sm sm:rounded-lg p-6'])); ?>>
    <?php echo e($slot); ?>

</div>

<?php /**PATH C:\xampp\fpw\resources\views/components/card.blade.php ENDPATH**/ ?>